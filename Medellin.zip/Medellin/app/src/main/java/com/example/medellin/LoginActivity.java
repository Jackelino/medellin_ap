package com.example.medellin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    TextView enlaceRegistro, enlaceRcuoaracion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        enlaceRegistro=(TextView)findViewById(R.id.idEnlaceRegistros);
        enlaceRegistro.setOnClickListener((View view) -> iniciarActivityRegistro(view) );

        enlaceRegistro=(TextView)findViewById(R.id.idEnlaceRcuperar);
        enlaceRegistro.setOnClickListener((View view) -> iniciarActivityRecuperacion(view) );
    }


    /** Called when the user taps the Send button */
    public void iniciarActivityLogin(View view) {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
        // Do something in response to button
    }

    public void iniciarActivityRegistro(View v) {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
        // Do something in response to button
    }
    public void iniciarActivityRecuperacion(View v) {
        Intent intent = new Intent(this, RestorePasswordActivity.class);
        startActivity(intent);
        // Do something in response to button
    }






}